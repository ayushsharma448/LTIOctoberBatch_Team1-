package com.example5.demo5.repository;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example5.demo5.Entity.AddCart;

@Repository
public interface AddCartRepository extends PagingAndSortingRepository<AddCart, Long>
{
	
		AddCart findByPidAndBuyerId(Long pid,Long buyerId);
	//List<AddCart> findByPidAndBuyerId(Long pid,Long buyerId);
	
	@Transactional	  
	  @Query(value="Update Add_Cart a SET a.purchase_qunatity =a.purchase_qunatity +:sQuant where a.pid=:pid AND a.buyer_id = :buyerId", nativeQuery=true)	  
	  @Modifying void updateQantityToAddCart(@Param("sQuant") Long sQuant,@Param("pid") Long pid,@Param("buyerId") Long buyerId);

	List<AddCart> findByBuyerId(Long buyerId);

		 
}
