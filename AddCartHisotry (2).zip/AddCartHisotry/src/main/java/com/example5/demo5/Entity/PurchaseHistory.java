package com.example5.demo5.Entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="PurchaseHistory")
public class PurchaseHistory {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private long id;
	
	@Column(name="pid")
	private Long pid;
	
	@Column(name="date")
	private Date date;
	
	@Column(name="buyerId")
	private long buyerId;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Long getPid() {
		return pid;
	}

	public void setPid(Long pid) {
		this.pid = pid;
	}

	public long getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(long buyerId) {
		this.buyerId = buyerId;
	}

	public long getPurchaseQunatity() {
		return purchaseQunatity;
	}

	public void setPurchaseQunatity(long purchaseQunatity) {
		this.purchaseQunatity = purchaseQunatity;
	}

	@Column(name="purchaseQunatity")
	private long purchaseQunatity;

	public PurchaseHistory() {
		super();
	}

	
}
