package com.example5.demo5.controller;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example5.demo5.Entity.AddCart;
import com.example5.demo5.Entity.PurchaseHistory;
import com.example5.demo5.repository.AddCartRepository;
import com.example5.demo5.repository.PurchaseHistoryRepo;

@CrossOrigin(origins = "*")
@RestController
public class CartProductHistoryController {

	
	
	@Autowired
	AddCartRepository addCartRepo;
	
	@Autowired
	PurchaseHistoryRepo purchaseHistoryRepo;
	
	@GetMapping("/geCartDtls")
	List<AddCart> geCartDtls()
	{
		return (List<AddCart>) addCartRepo.findAll();
	}
	
	@PostMapping("/addToCartService")
	AddCart addToCartService(@Valid @RequestBody AddCart addCart)
	{		
		AddCart ls=addCartRepo.findByPidAndBuyerId(addCart.getPid(),addCart.getBuyerId());
		if(ls!=null)
		{
			// incr, decr should be handled from front end, we are replacing qunatity----just pass final updated quantity
			addCartRepo.updateQantityToAddCart(addCart.getPurchaseQunatity(),addCart.getPid(),addCart.getBuyerId());
			return null;
		}
		return addCartRepo.save(addCart);
	}
	
	// not using as of now
	@PostMapping("/addProductToCart")
	AddCart addProductToCart(@RequestParam(value="buyerId") Long buyerId,@RequestParam(value="pId") Long pId,
			@RequestParam(value="purchaseQuantity") Long purchaseQuantity)
	{				
		
		AddCart ls=addCartRepo.findByPidAndBuyerId(pId,buyerId);
		if(ls!=null)
		{
			// incr, decr should be handled from front end, we are replacing qunatity----just pass final updated quantity
			addCartRepo.updateQantityToAddCart(purchaseQuantity,pId,buyerId);
			return null;
		}
		
		
		AddCart addCart=new AddCart();
		addCart.setBuyerId(buyerId);
		addCart.setPid(pId);
		addCart.setPurchaseQunatity(purchaseQuantity);		
		addCartRepo.save(addCart);
		return addCartRepo.save(addCart);
	}
	
	
	@DeleteMapping("/deleteByPId")
	AddCart deleteById(@RequestParam(value="pid") Long pid,@RequestParam(value="buyerId")
	Long buyerId) 
	{
		AddCart ls=addCartRepo.findByPidAndBuyerId(pid,buyerId);
		addCartRepo.deleteById(ls.getId());
		return null;
		
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/deleteAllCartData")
	String deleteAllCartData(@RequestParam(value="buyerId") Long buyerId,
	@RequestParam(value="index") Long index) 
	{
		if(index==0)
		{
		addCartRepo.deleteAll();		
		return "deleted all from Cart";
		}
		else
		{
			//add to purchase as well
			List<AddCart> listHistory= addCartRepo.findByBuyerId(buyerId);
			for (AddCart addCart : listHistory)
			{
				PurchaseHistory ph= new PurchaseHistory();
				ph.setPid(addCart.getPid());
				ph.setDate(new Date());
				ph.setBuyerId(addCart.getBuyerId());
				ph.setPurchaseQunatity(addCart.getPurchaseQunatity());
				purchaseHistoryRepo.save(ph);
				addCartRepo.deleteById(addCart.getId());
			}
		//	addCartRepo.deleteAll();
		return "success";
		}
	}
	
	
}
