package com.example5.demo5.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.example5.demo5.Entity.Product;
import com.example5.demo5.repository.ProductRepo;

@RunWith(MockitoJUnitRunner.class)
public class ServiceTest {

	@Mock
	ProductRepo prodRepo;
	
	@Mock
	ProductRepo productRepo;

	@InjectMocks
	ProductServiceImpl prodServiceimpl;

	@Test
	public void addProductSuccessTest() {
		Product prod = new Product();
		Product prodRes = new Product();
		prodRes.setId(1);
		when(prodRepo.save(prod)).thenReturn(prodRes);
		Product p1 = prodServiceimpl.addProduct(prod);
		assertEquals(prodRes, p1);
	}
	
	@Test
	public void  getAllSuccessTest() {
		List<Product> listProd = new ArrayList<>();
		listProd.add(new Product());
		when(productRepo.findAll()).thenReturn(listProd);
		List<Product> l=prodServiceimpl.getProductDtls();
		assertEquals(listProd, l);	
	}
	
	
}

