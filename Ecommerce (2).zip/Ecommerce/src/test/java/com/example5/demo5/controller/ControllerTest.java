package com.example5.demo5.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.example5.demo5.Entity.Product;
import com.example5.demo5.Entity.Seller;
import com.example5.demo5.controller.ShoppingController;
import com.example5.demo5.repository.ProductRepo;
import com.example5.demo5.repository.SellerRepo;
import com.example5.demo5.service.ProductService;

@RunWith(MockitoJUnitRunner.class)
public class ControllerTest {
	@Mock
	ProductService prodService;
	
	@Mock
	ProductRepo prodRepo;

	@Mock
	SellerRepo sellerRepo;

	@InjectMocks
	ShoppingController shoppingController;

	@Test
	public void addProductSuccessTest() {
		Product prod = new Product();
		Product prodRes = new Product();
		prodRes.setId(1);
		when(prodService.addProduct(prod)).thenReturn(prodRes);
		Product prodControllerRes = shoppingController.addProduct(prod);
		// assertNotNull(prodRes);
		assertEquals(prodRes, prodControllerRes);
	}

	@Test
	public void createSellerSuccessTest() {
		List<Seller> sell=new ArrayList<>();
		sell.add(new Seller());
		long sid = 1;
		long pid = 2;
		Seller seller =new Seller();
		when(sellerRepo.findAbc(sid, pid)).thenReturn(sell);
		Seller sel=shoppingController.createSeller(pid, sid, seller);
		assertEquals(sell.get(0),sel);
		//when(sellerRepo.updateQantityToSeller(seller.getsQuantity(),sid,pid));	
	}
	
	@Test
	public void insertSellerSuccessTest() {
		List<Seller> sell=new ArrayList<>();
		Seller seller1 = new Seller();
		Seller seller2 = new Seller();
		seller2.setSellerId(1);
		long sid = 1;
		long pid = 2;
		when(sellerRepo.findAbc(sid, pid)).thenReturn(sell);
		Optional<Product> product=Optional.of(new Product());
		when(prodRepo.findById(pid)).thenReturn(product);
		seller1.setProduct(product.get());
		when(sellerRepo.save(seller1)).thenReturn(seller2);
		Seller sel=shoppingController.createSeller(pid, sid, seller1);
		assertEquals(seller2, sel);
	}	

	
	
}

